package com.ssafy.homework.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.homework.model.dto.Product;
import com.ssafy.homework.model.repository.ProductRepo;

@Service("pService")
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepo productRepo;

	public void setProductRepo(ProductRepo productRepo) {
		this.productRepo = productRepo;
	}

	@Override
	public ProductRepo getRepo() {
		return productRepo;
	}

	@Override
	public List<Product> selectAll() throws Exception {
		return productRepo.selectAll();
	}

	@Override
	public Product select(String id) throws Exception {
		return productRepo.select(id);
	}

	@Override
	public int insert(Product product) throws Exception {
		return productRepo.insert(product);
	}

	@Override
	public int update(Product product) throws Exception {
		return productRepo.update(product);
	}

	@Override
	public int delete(String id) throws Exception {
		return productRepo.delete(id);
	}

}
