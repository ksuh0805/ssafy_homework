package com.ssafy.homework.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssafy.homework.model.dto.Product;
import com.ssafy.homework.model.service.ProductService;
import com.ssafy.homework.model.service.ProductServiceImpl;

public class BeanTest {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"com/ssafy/homework/test/applicationContext2.xml");
		ProductService service=context.getBean("pService", ProductServiceImpl.class);
		try {
			List<Product> products = service.selectAll();
			for (Product product : products) {
				System.out.println(product);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
